# MultiPandOS

To compile the project:
```bash
mkdir -p build && pushd build && cmake .. && make && popd
```
