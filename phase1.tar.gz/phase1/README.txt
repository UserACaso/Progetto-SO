Progetto SO 24/25 - Phase 1
Il progetto contiene due file principali nella cartella starterKit/phase1:
    • pcb.c: funzioni per inizializzazione e gestione dei PCB
    • asl.c: funzioni per inizializzazione e gestione dei semafori
L'eseguibile si trova nella cartella build. Per ricompilare il progetto, entrare nella cartella build ed
eseguire il comando make da terminale.
