Progetto SO 24/25 - Phase 2

Il progetto contiene i seguenti file principali nella cartella Progetto-SO-main/phase2:

File di implementazione:
- initial.c: Inizializzazione del Nucleus e variabili globali
- scheduler.c: Implementazione dello scheduler round-robin
- exceptions.c: Gestione delle eccezioni (TLB, Program Trap, SYSCALL)
- interrupts.c: Gestione degli interrupt dei dispositivi e timer

Headers:
Nella sottocartella headers/ sono presenti i seguenti file header:
- exceptions.h
- initial.h
- interrupts.h
- scheduler.h

Per ricompilare il progetto:
1. Entrare nella cartella build: cd build
2. Eseguire il comando: cmake .. && make
